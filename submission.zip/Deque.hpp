#ifndef DEQUE_HPP
#define DEQUE_HPP

#include "abstract_deque.hpp"

template <typename T>
class Deque: public AbstractDeque<T>
{
  //TODO
public:

	/** Default Constructor: builds the object, and sets default value
	*/
	Deque();

	/** Destructor: destroys the object after completion, preventing memory leaks
	*/
	~Deque();

	/** Returns true if the deque is empty, else false
	*/
	bool isEmpty() const noexcept;

	/** Add item to the front of the deque
	 * may throw std::bad_alloc
	 */
	void pushFront(const T& item);

	/** Remove the item at the front of the deque
	 * throws std::runtime_error if the deque is empty
	 */
	void popFront();

	/** Returns the item at the front of the deque
	 * throws std::runtime_error if the deque is empty
	 */
	const T& front() const throw(std::runtime_error);

	/** Add item to the back of the deque
	 * may throw std::bad_alloc
	 */
	void pushBack(const T& item);

	/** Remove the item at the back of the deque
	 * throws std::runtime_error if the deque is empty
	 */
	void popBack();

	/** Returns the item at the back of the deque
	 * throws std::runtime_error if the deque is empty
	 */
	const T& back() const throw(std::runtime_error);

private:
	// element in the front of the circular array
	std::size_t front_t;

	// element in the back of the circular array
	std::size_t rear_t;

	// size of the circular array
	std::size_t count;

	// elements in the circular array
	std::size_t capacity;

	// the circular array
	T* myArr;

	/** isFull function that checks if the array is full or not
	* returns true if full, false otherwise
	*/
	bool isFull();
	
	/** function that implements the growing algorithm for
	* the circular array. throws a bad allocation error if out of range
	* returns void (nothing).
	*/
	void enlarge();
};

#include "Deque.txx"
#endif
